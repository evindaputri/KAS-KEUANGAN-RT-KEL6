package com.example.kasrt.model

data class ResponseUser(val data: List<DataItem>)